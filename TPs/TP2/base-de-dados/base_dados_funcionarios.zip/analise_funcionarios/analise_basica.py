import pandas as pd

#Carregar os arquivos
df = pd.read_csv("base_dados_funcionarios.csv")

#Head exibe as primeiras linhas, neste caso as 20 primeiras
print(df.head(20))

#Gostaria de saber quantos funcionarios por departamento
funcionarios_por_departamento = df['Departamento'].value_counts()
print(funcionarios_por_departamento)

#Gostaria de saber funcionarios que ganham menos de 3000 reais
salarios = df[df['Salario'] < 3000]
print(salarios)

#Calcular a média de idade por departamento
idade_media = df.groupby("Departamento")["Idade"].mean()
print(idade_media)

#Encontrar o funcionario com o maior salario de cada departamento
funcionario_bem_pago = df.groupby("Departamento")["Salario"].idxmax()
print(df.loc[funcionario_bem_pago])



